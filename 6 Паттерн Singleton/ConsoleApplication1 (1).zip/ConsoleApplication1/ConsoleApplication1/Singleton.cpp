#include "Singleton.h"

Singleton* Singleton::p_instance = 0;

