#include "Singleton.h"

Singleton* Singleton::p_instance = 0;
SingletonDestroyer Singleton::destroyer;